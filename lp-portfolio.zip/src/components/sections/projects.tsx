export default function Projects() {
  return (
    <div id="projects" className="w-full h-screen bg-green-500 flex justify-center items-center snap-start">Projects</div>
  )
}