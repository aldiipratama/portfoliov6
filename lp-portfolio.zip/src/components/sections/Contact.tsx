export default function Contact() {
  return (
    <div id="contact" className="w-full h-screen bg-yellow-500 flex justify-center items-center snap-start">Contact</div>
  )
}